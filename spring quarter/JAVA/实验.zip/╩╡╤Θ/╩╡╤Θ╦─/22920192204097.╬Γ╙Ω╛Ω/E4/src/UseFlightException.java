public class UseFlightException {
    private String name;
    private String reason;
    private String state;
    private String normalState = "normal";

    public UseFlightException() {
    }

    public UseFlightException(String name, String state, String reason) {
        this.reason = reason;
        this.name = name;
        this.state = state;
    }

    public void Test(String name, String state, String reason)
            throws FlightWeatherException, FlightTrafficControlException, FlightWarAheadException, FlightMachineStoppageException {
        if (!state.equals(this.normalState)) {//如果航班状态不正常，则抛出异常
            if (reason.equals("weather")) {//天气原因
                throw new FlightWeatherException(" and the reason is the bad weather.");
            } else if (reason.equals("traffic control")) {//交通流量管制
                throw new FlightTrafficControlException(" and the reason is traffic control.");
            } else if (reason.equals("war ahead")) {//前方战争
                throw new FlightWarAheadException(" and the reason is a war ahead.");
            } else if (reason.equals("machine stoppage")) {//机器故障停转
                throw new FlightMachineStoppageException(" and the reason is the machine stoppage.");
            }
        }
        else {//如果航班状态正常，输出航班状态正常信息
            System.out.println("Your flight " + name + "'s state is normal.");
        }

    }
}
