public class FlightWeatherException extends FlightException{

    private String message=" and the reason is the bad weather.";
    public FlightWeatherException(){
    }
    public FlightWeatherException(String message){
        super();
        this.message=message;
    }
    public String getMessage(){
        return message;
    }
}
