public class FlightWarAheadException extends FlightException{
    private String message=" and the reason is a war ahead.";
    public FlightWarAheadException(){
    }
    public FlightWarAheadException(String message){
        super();
        this.message=message;
    }
    public String getMessage(){
        return message;
    }
}
