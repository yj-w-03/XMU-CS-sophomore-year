
import java.util.Scanner;

public class TestException {
    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        String name=input.nextLine();//输入
        String state=input.nextLine();
        String reason=input.nextLine();
        UseFlightException test=new UseFlightException();
        try {//检查航班状态是否正常
            test.Test(name,state,reason);
        }
        catch (FlightWeatherException ex1){//如果航班状态不正常，输出异常信息
            System.out.println(ex1.get1()+name+ex1.get2()+state+ex1.getMessage());
        }
        catch (FlightTrafficControlException ex2){
            System.out.println(ex2.get1()+name+ex2.get2()+state+ex2.getMessage());
        }
        catch (FlightWarAheadException ex3){
            System.out.println(ex3.get1()+name+ex3.get2()+state+ex3.getMessage());
        }
        catch (FlightMachineStoppageException ex4){
            System.out.println(ex4.get1()+name+ex4.get2()+state+ex4.getMessage());
        }
    }
}
