public class FlightMachineStoppageException extends FlightException{
    private String message=" and the reason is traffic control.";
    public FlightMachineStoppageException(){
    }
    public FlightMachineStoppageException(String message){
        super();
        this.message=message;
    }
    public String getMessage(){
        return message;
    }
}
