public class FlightException extends Exception{//自定义一个异常类，继承exception
    String father1="Your flight ";
    String father2=" has been ";
    public FlightException(){

    }
    public FlightException(String m1,String m2){
        super();
        this.father1=m1;
        this.father2=m2;
    }
    public String get1(){
        return father1;
    }
    public String get2(){
        return father2;
    }
}
