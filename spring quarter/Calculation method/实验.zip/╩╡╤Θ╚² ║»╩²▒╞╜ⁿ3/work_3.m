clear;
N=16;
A1=zeros(1,N);
A2=zeros(1,N);
w=exp(i*2*pi/N);
x=-pi:2*pi/16:pi;
y=x.^2.*cos(x);
A1=y;
p=log2(N);
for q=1:p
    if(mod(q,2)==1)
        for k=0:2^(p-q)-1
            for j=0:2^(q-1)-1
                temp1=A1(k*2^(q-1)+j+1);
                temp2=A1(k*2^(q-1)+j+2^(p-1)+1);
                A2(k*2^q+j+1)=temp1+temp2;
                A2(k*2^q+j+2^(q-1)+1)=(temp1-temp2)*w^(-k*2^(q-1));
            end
        end
    end
    if(mod(q,2)==0)
        for k=0:2^(p-q)-1
            for j=0:2^(q-1)-1
                temp1=A2(k*2^(q-1)+j+1);
                temp2=A2(k*2^(q-1)+j+2^(p-1)+1);
                A1(k*2^q+j+1)=temp1+temp2;
                A1(k*2^q+j+2^(q-1)+1)=(temp1-temp2)*w^(-k*2^(q-1));
            end
        end
    end
end
syms z
a=zeros(1,N);
b=zeros(1,N);
for p=0:N-1
    a(p+1)=real(A1(p+1)*exp(-i*p*pi))/(N/2);
    b(p+1)=imag(A1(p+1)*exp(-i*p*pi))/(N/2);
end
f=a(1)/2;
for p=1:N/2
    f=f+a(p+1)*cos(p*z)+b(p+1)*sin(p*z);
end
fplot(f,'r');
hold on
ff=z^2*cos(z);
fplot(ff,'g');
legend('三角插值多项式','f(x)');
                
        
        
        
        