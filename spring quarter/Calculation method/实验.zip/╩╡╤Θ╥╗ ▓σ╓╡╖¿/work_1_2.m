clear;
x=-1:0.2:1;
y=1./(1+25*x.^2);
x0=[-1:0.2:1];
x00=[-1:0.2:1];
y1=lagrange(x,y,x0);
y11=lagrange(x,y,x00);
y0=1./(1+25*x0.^2);
y00=1./(1+25*x0.^2);
%plot(x0,y,'*',x0,y0,'b',x0,y1,'r');
%hold on;        
%s=threesimple(x0,y0,x);
%plot(x0,s,'g'); 
%hold off;
%title('n=10时');
%legend('节点','f(x)','拉格朗日多项式插值','三次样条插值');
%r1=y1-y;
%pp = csape(x,y,'variational');
%y2=ppval(pp,x0);
%r2=y00-y2;




