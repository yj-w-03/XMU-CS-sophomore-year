clear;
x=[0 1 4 9 16 25 36 49 64];
y=[0 1 2 3 4 5 6 7 8];
x2=0:0.01:1;
y11=zeros(1,101);
i=1;
for m=0:0.01:1
    n=lagrange(x,y,m);
    y11(i)=n;
    i=i+1;
end
y0=1;
yn=0.0625;
ss=threesimple1(x,y,x2,y0,yn);
y33=sqrt(x2);
plot(x,y,'*',x2,y11,'g',x2,ss,'r',x2,y33,'b');
legend('节点','拉格朗日插值函数','三次样条插值函数','平方根函数f(x)');