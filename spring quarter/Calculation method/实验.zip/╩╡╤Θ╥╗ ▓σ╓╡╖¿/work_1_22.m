clear;
x=-1:0.1:1;
y=1./(1+25*x.^2);
x0=[-1:0.1:1];
y0=lagrange(x,y,x0);
y1=1./(1+25*x0.^2);
plot(x,y,'*',x0,y1,'b',x0,y0,'-r');
hold on;        
s=threesimple(x0,y1,x);
plot(x,s,'g'); 
hold off;
title('n=20时');
legend('节点','f(x)','拉格朗日多项式插值','三次样条插值');

