function s=threesimple(X,Y,x) 
n=length(X); 
A=zeros(n,n);
h=zeros(n-1,1);
u=zeros(n-2,1);
l=zeros(n-2,1);
A(:,1)=Y';
D=zeros(n-2,n-2);
d=zeros(n-2,1);
for  j=2:n
    for i=j:n
        A(i,j)=(A(i,j-1)- A(i-1,j-1))/(X(i)-X(i-j+1));
    end
end
for i=1:n-1
    h(i)=X(i+1)-X(i);
end        
for i=1:n-2
    D(i,i)=2;
    d(i,1)=6*A(i+2,3);
end
for i=2:n-2
    u(i)=h(i)/(h(i)+h(i+1));
    l(i-1)=h(i)/(h(i-1)+h(i));
    D(i-1,i)=l(i-1);
    D(i,i-1)=u(i);             
end
M=D\d;
M=[0;M;0];
m=length(x);    
for t=1:m
    for j=1:n-1
        if (x(t)<=X(j+1))&&(x(t)>=X(j))
            p1=M(j,1)*(X(j+1)-x(t))^3/(6*h(j));
            p2=M(j+1,1)*(x(t)-X(j))^3/(6*h(j));
            p3=(Y(j)-M(j,1)/6*(h(j))^2)*(X(j+1)-x(t))/h(j);
            p4=(Y(j+1)-M(j+1,1)/6*(h(j))^2)*(x(t)-X(j))/h(j);
            s(t)=p1+p2+p3+p4; 
            break;
         else
            s(t)=0; 
        end
    end
end
end





pp=csape(x0,y0,'variational');
f3=ppval(pp,x00);
plot(x00,f3,'g');

