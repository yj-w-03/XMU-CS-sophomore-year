function s=three(X,Y,x,y0,yn) 
n=length(X);
A=zeros(n,n);
A(:,1)=Y';
D=zeros(n,n);
d=zeros(n,1);
for j=2:n
    for i=j:n
        A(i,j)=(A(i,j-1)- A(i-1,j-1))/(X(i)-X(i-j+1));
    end
end         
for i=1:n-1
    h(i)=X(i+1)-X(i);
end
for i=1:n
    D(i,i)=2;
    D(1,2)=1;
    D(n,n-1)=1;
    if (i==1)
        d(i,1)=6/h(i)*(A(2,2)-y0);
    elseif (i==n)
        d(i,1)=6/h(i-1)*(yn-A(i,2));
    else
        d(i,1)=(6/(h(i-1)+h(i)))*(A(i+1,2)-A(i,2));
    end
end
for i=1:n-2
    u(i)=h(i)/(h(i)+h(i+1));
    l(i)=1-u(i);
    D(i+1,i+2)=l(i);
    D(i+1,i)=u(i);          
end
M=D\d;
m=length(x);
for t=1:m
    for i=1:n-1
        if (x(t)<=X(i+1))&&(x(t)>=X(i))
            p1=M(i,1)*(X(i+1)-x(t))^3/(6*h(i));
            p2=M(i+1,1)*(x(t)-X(i))^3/(6*h(i));
            p3=(A(i,1)-M(i,1)/6*(h(i))^2)*(X(i+1)-x(t))/h(i);
            p4=(A(i+1,1)-M(i+1,1)/6*(h(i))^2)*(x(t)-X(i))/h(i);
            s(t)=p1+p2+p3+p4;
            break;
        else
            s(t)=0;
        end
    end
end
end
