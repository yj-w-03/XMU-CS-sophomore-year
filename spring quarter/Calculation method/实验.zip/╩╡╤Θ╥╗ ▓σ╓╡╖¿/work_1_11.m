clear;
xi=[0.2 0.4 0.6 0.8 1.0];
yi=[0.98 0.92 0.81 0.64 0.38];
x=sym('x');
p= Newton2(x,xi,yi);
xx=0.2:0.08:1.0;
p=subs(p,x,xx);
plot(xx,p);
title('4次牛顿插值函数');         
s=threesimple(xi,yi,xx);
plot(xx,s);        
title('三次样条函数');

