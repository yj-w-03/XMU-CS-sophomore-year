clear;
A=[0.2 0.98;0.4 0.92;0.6 0.81;0.8 0.64;1.0 0.38];
x0=[0.2 0.4 0.6 0.8 1.0];
y0=[0.98 0.92 0.81 0.64 0.38];
x=0.2:0.08:1.0;
y1=zeros(1,10);
i=1;
for m=0.2:0.08:1.0
    n=newton(m,4,A);%4次牛顿插值
    y1(i)=n;
    i=i+1;
end
%三次样条插值
pp=csape(x0,y0,'variational');
y2=ppval(pp,x);
%画图
plot(x,y1,x,y2);
hold on;
xx=0.2:0.08:1.0;
for j=1:10
    plot(xx(j),y1(j),'bo');
    plot(xx(j),y2(j),'r+');
end
title('4次牛顿插值与3次样条函数');
legend('4次牛顿插值多项式P4(x)','三次样条函数S(x)');
hold off;



