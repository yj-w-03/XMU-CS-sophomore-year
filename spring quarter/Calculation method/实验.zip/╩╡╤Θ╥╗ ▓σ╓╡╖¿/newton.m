function y = newton(x,n,A)
%计算差分表
for j=3:n+2
    for i=j-1:n+1
        A(i,j)=( A(i,j-1)-A(i-1,j-1) )/( A(i,1)-A(i+2-j,1) );
    end
end
y=0;
%计算牛顿插值函数
for i=1:n+1
    S=1;
    for j=i-1:-1:1
        S=S*(x-A(j,1));
    end
    y=y+A(i,i+1)*S;
end




