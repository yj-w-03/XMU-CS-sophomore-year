function P= Newton2(x,xi,yi)
n=length(xi);
A=zeros(n,n);
%赋初始值
for k=1:n      
    A(k,1)=yi(k);
end
% 求差分表
for i=2:n      
    for j=i:n
        A(j,i)=(A(j,i-1)-A(j-1,i-1))/(xi(j)-xi(j+1-i));  
    end
end
disp('差分表如下：');
disp(A);
%求插值多项式
P=0;          
for k=2:n
    t=1;
    for j=1:k-1
        t=t*(x-xi(j));
    end
    P=A(k,k)*t+P;
end
P=A(1,1)+P;
disp('P=');
disp(P);
end


