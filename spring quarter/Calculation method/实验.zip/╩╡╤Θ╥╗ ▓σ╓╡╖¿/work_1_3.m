clear;
x=[0 1 4 9 16 25 36 49 64];
y=[0 1 2 3 4 5 6 7 8];
x1=0:0.1:64;
y1=zeros(1,64);
i=1;
for m=0:0.1:64
    n=lagrange(x,y,m);
    y1(i)=n;
    i=i+1;
end
plot(x1,y1)
title('8次拉格朗日多项式插值');
y0=1;
yn=0.0625;
s=three(x,y,x1,y0,yn);
plot(x1,s);
title('三次样条插值（第一边界条件）');
y3=sqrt(x1);
plot(x,y,'*',x1,y1,'r',x1,s,'g',x1,y3,'b');
legend('节点','拉格朗日插值函数','三次样条插值函数','平方根函数f(x)');
x2=0:0.01:1;
y11=zeros(1,101);
i=1;
for m=0:0.01:1
    n=lagrange(x,y,m);
    y11(i)=n;
    i=i+1;
end
ss=three(x,y,x2,y0,yn);
y33=sqrt(x2);
plot(x2,y11,'r',x2,ss,'g',x2,y33,'b');
legend('拉格朗日插值函数','三次样条插值函数','平方根函数f(x)');