clear
clc
syms x 
%------------------------------------------------------------
%Variables to be set
xx = [-1:0.2:1];% The nodes（needs to be arranged in order)
y=1./(1+25*x.^2); % The function needed to be interpolated
%--------------------------------------------------------------
yy = subs(y,x,xx);
num = length(xx); 
dy = abs(diff(y,num));
l = [];
L = [];
R = [];
for n = 1:num
    temp = xx;
    temp(n) =[];
    for m = 1:num-1
        l = [l (x-temp(m))/(xx(n)-temp(m))];
    end 
    L = [L prod(l)*yy(n)];
    l = [];
end

L = vpa(collect(sum(L),x));
M = eval(max(subs(dy,x,[xx(1):0.01:xx(end)])));
for n = 1:num
    R = [R x-xx(n)];
end
R = vpa(M/factorial(num)*abs(prod(R)));

disp('拉格朗日多项式插值函数')
disp(L)
disp('截断误差限')
disp(R)
