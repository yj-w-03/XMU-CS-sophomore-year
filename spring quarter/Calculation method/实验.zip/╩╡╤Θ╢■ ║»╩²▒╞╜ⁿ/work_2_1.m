syms x
x0=[-1:0.2:1];
y=1./(1+25*x0.^2);
A=zeros(4,4);
%按照公式计算4*4矩阵A
for i=1:4
    for j=1:4
        A(i,j)=sum(x0.^(i+j-2));
    end
end
B=zeros(1,4);
%计算矩阵B的逆
for i=1:4
    B(i)=sum(y.*x0.^(i-1));
end
B=B';
%计算d
d=inv(A)*B;
%打印拟合方程
f2=d(1)+d(2)*x+d(3)*x^2+d(4)*x^3;
f2
%画出原函数图像和拟合曲线图像
fplot(f1)
axis([-2 2 -0.5 1.5])
hold on
fplot(f2)
hold off