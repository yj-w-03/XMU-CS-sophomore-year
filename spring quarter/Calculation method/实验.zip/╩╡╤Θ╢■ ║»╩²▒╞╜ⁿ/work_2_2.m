syms x
x0=[0.0,0.1,0.2,0.3,0.5,0.8,1.0];
y0=[1.0,0.41,0.50,0.61,0.91,2.02,2.46];
x00=0:0.02:1;
A1=zeros(4,4);
B1=zeros(1,4);
for i=1:4
    for j=1:4
        A1(i,j)=sum(x0.^(i+j-2));
    end
end
for i=1:4
    B1(i)=sum(y0.*x0.^(i-1));
end
B1=B1';
d1=inv(A1)*B1;
f1=d1(1)+d1(2)*x+d1(3)*x^2+d1(4)*x^3;
f1
fplot(f1);
axis([-0.5 1.5 0 3]);
hold on
A2=zeros(5,5);
B2=zeros(1,5);
for i=1:5
    for j=1:5
        A2(i,j)=sum(x0.^(i+j-2));
    end
end
for i=1:5
    B2(i)=sum(y0.*x0.^(i-1));
end
B2=B2';
d2=inv(A2)*B2;
f2=d2(1)+d2(2)*x+d2(3)*x^2+d2(4)*x^3+d2(5)*x^4;
f2
fplot(f2);
%f3=threesimple(x0,y0,x);
%plot(x0,f3,'g'); 

pp=csape(x0,y0,'variational');
f3=ppval(pp,x00);
plot(x00,f3,'g');
scatter(x0,y0);
legend('3次多项式曲线拟合','4次多项式曲线拟合','3次样条插值');
%legend('3次样条插值');

