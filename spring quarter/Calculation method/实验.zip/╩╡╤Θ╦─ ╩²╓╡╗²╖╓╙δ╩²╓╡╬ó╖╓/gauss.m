function q=gauss(F,x0,a,b,n)
syms t;
F=subs(F,x0,(b-a)/2*t+(a+b)/2);
[x,A]=gausspoints(n);
q=(b-a)/2*sum(A.*subs(F,t,x));

