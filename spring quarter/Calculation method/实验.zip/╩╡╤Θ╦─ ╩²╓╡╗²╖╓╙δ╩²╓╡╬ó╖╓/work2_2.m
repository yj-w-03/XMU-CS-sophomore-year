a=0;b=1;
epsilon=1e-5;
f = @(x)sqrt(x)*log(x);
[R,k,T] = Romberg(f,a,b,epsilon);
fprintf("积分结果是    %f\r\n",R); %打印积分结果
fprintf("k=  %f\r\n",k); %打印迭代次数
disp(T); %打印T-表