clear;
y=@(x)x^2.*log(x);
a=1;
b=1.5;
eps=1e-3;
result=S_simpson(y,a,b,eps)


