function I=C_T(f,a,b,n)
format long             
h=(b-a)/n;
x=linspace(a,b,n+1);
y=feval(f,x); 
I=h*(0.5*y(1)+sum(y(2:n))+0.5*y(n+1));

