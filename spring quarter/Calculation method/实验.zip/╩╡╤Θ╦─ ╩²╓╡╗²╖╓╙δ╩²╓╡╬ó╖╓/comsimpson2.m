function Q=comsimpson2(F,x0,a,b,n)
x=linspace(a,b,n+1);
Q=0;
for k=1:n
    Q=Q+subs(F,x0,x(k))+4*subs(F,x0,(x(k)+x(k+1))/2)+subs(F,x0,x(k+1));
end
Q=Q*(b-a)/n/6;


