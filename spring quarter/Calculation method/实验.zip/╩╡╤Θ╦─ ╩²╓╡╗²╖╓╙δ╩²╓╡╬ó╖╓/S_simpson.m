function y=S_simpson(f,a,b,eps)
c=(a+b)/2;
if abs(simpson(f,a,c)+simpson(f,c,b)-simpson(f,a,b))<15*eps
    y=simpson(f,a,c)+simpson(f,c,b)+(simpson(f,a,c)+simpson(f,c,b)-simpson(f,a,b))/15;
else
    y=S_simpson(f,a,c,eps/2)+S_simpson(f,c,b,eps/2);
end

