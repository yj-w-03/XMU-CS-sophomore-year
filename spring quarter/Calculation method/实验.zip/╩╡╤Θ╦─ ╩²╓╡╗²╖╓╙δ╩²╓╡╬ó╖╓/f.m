function y=f(x)
y=sqrt(x).*log(x);

