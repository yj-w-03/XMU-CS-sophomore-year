clear;
format long;
T=zeros(1,10);
S=zeros(1,10);
h=zeros(1,10);
for i=1:10
    F=C_T(0,1,10*i);
    T(i)=-4/9-F;
    F=C_S(0,1,10*i);
    S(i)=-4/9-F;
    h(i)=1/(10*i);
end
TT=polyfit(h,T,2);%对h和复合梯形公式计算误差进行2次拟合
SS=polyfit(h,S,4);%对h和复合辛普森公式计算误差进行4次拟合


