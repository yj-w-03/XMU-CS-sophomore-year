f=@(x,y) exp(-x.*y);
s=dblquad(f,0,1,0,1,1.0e-3)