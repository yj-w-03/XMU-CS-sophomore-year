clear;
format long;
s=input('Enter function：fx = ','s');
fx=inline(s);
a=input('Enter a:');
b=input('Enter b:');
accuracy=input('Enter accuracy:');
h=b-a;
T=zeros(16+1,16+1);
T(1,1)=(h/2)*(fx(a)+fx(b));
for k =1:16 
    sum=0;
    d1=(b-a)/2^(k-1); 
    d2=d1/2; 
    for i=0:(2^(k-1)-1)
        sum=sum + fx(a + i * d1 + d2);
    end
    T(k+1,0+1) = 0.5*T(k-1 +1, 0 +1)+h/2*sum; 
    for m=1:k
        T(k+1,m+1)=(4^m /(4^m-1))*T(k+1,m-1+1)-(1/(4^m - 1))*T(k-1 +1, m-1 +1);
    end
    if abs(T(k +1, m +1) - T(k-1 +1, m-1 +1)) <= accuracy
       result=T(k +1, m +1);
       result
       break;
    end
    h=h/2;
end
disp('T表:')
disp(T(1:k+1, 1:m+1));


