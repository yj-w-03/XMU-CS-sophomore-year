clear;

T10=C_T(f,0,1,10);
T20=C_T(f,0,1,20);
T50=C_T(f,0,1,50);
T100=C_T(f,0,1,100);
S10=C_S(f,0,1,10);
S20=C_S(f,0,1,20);
S50=C_S(f,0,1,50);
S100=C_S(f,0,1,100);
function y=f(x)
y=sqrt(x).*log(x);
end




