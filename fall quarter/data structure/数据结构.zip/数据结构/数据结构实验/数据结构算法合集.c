/*                       ---------ϡ�����ӷ�----------
#include <stdio.h>
#include<stdlib.h>
typedef struct
{
    int i;
    int j;
    int e;
} Triple;

typedef struct
{
    Triple data[10000];
    int mu,nu,tu;
} TS;

int main()
{
    int row,col,p,q,k=0,num;
    TS A,B,C;
    scanf("%d %d",&A.mu,&A.nu);
    B.mu=A.mu;
    C.mu=A.mu;
    B.nu=A.nu;
    C.nu=A.nu;
    scanf("%d",&A.tu);
    for(p=0; p<A.tu; p++) //�������A
    {
        scanf("%d %d %d",&A.data[p].i,&A.data[p].j,&A.data[p].e);
    }
    scanf("%d",&B.tu);
    for(q=0; q<B.tu; q++) //�������B
    {
        scanf("%d %d %d",&B.data[q].i,&B.data[q].j,&B.data[q].e);
    }
    row=A.mu;
    col=A.nu;
    p=0;
    q=0;
    while(p<A.tu&&q<B.tu)
    {
        if(A.data[p].i==B.data[q].i)
        {
            if(A.data[p].j==B.data[q].j)
            {
                C.data[k].i=A.data[p].i;
                C.data[k].j=A.data[p].j;
                C.data[k].e=A.data[p].e+B.data[q].e;
                k++;p++;q++;
            }
            else if(A.data[p].j<B.data[q].j)
            {
                C.data[k].i=A.data[p].i;
                C.data[k].j=A.data[p].j;
                C.data[k].e=A.data[p].e;
                k++;p++;
            }
            else if(A.data[p].j>B.data[q].j)
            {
                C.data[k].i=B.data[p].i;
                C.data[k].j=B.data[p].j;
                C.data[k].e=B.data[p].e;
                k++;q++;
            }
        }
        else if(A.data[p].i<B.data[q].i)
        {
                C.data[k].i=A.data[p].i;
                C.data[k].j=A.data[p].j;
                C.data[k].e=A.data[p].e;
                k++;p++;
        }
        else if(A.data[p].i>B.data[q].i)
        {
                C.data[k].i=B.data[p].i;
                C.data[k].j=B.data[p].j;
                C.data[k].e=B.data[p].e;
                k++;q++;
        }
    }
    if(p<A.tu)//���B��Ԫ���þ�����A����ʣ��
    {
        for(;p<A.tu;p++)
        {
                C.data[k].i=A.data[p].i;
                C.data[k].j=A.data[p].j;
                C.data[k].e=A.data[p].e;
                k++;
        }
    }
    else if(q<B.tu)//���A��Ԫ���þ�����B����ʣ��
    {
                C.data[k].i=B.data[p].i;
                C.data[k].j=B.data[p].j;
                C.data[k].e=B.data[p].e;
                k++;
    }
    printf("%d\n",k);
    for(num=0;num<k;num++)
    {
        printf("%d %d %d\n",C.data[num].i,C.data[num].j,C.data[num].e);
    }
    return 0;
}*/

/*                       ------------ϡ�����ת�ã�1��--------
#include <stdio.h>
#include<stdlib.h>
typedef struct{      //����Ԫ��
    int i,j,e;
}Triple;

typedef struct{       //����
    Triple data[1000];
    int mu,nu,tu;
}TS;
int main()
{
    int p,k,t,num=0,q;
    TS A,B;
    scanf("%d %d %d",&A.mu,&A.nu,&A.tu);
    for(p=0;p<A.tu;p++)
    {
        scanf("%d %d %d",&A.data[p].i,&A.data[p].j,&A.data[p].e);
    }
    for(k=0;k<A.nu;k++)
        for(t=0;t<A.tu;t++)
    {
        if(A.data[t].j==k)
        {
            B.data[num].i=A.data[t].j;
            B.data[num].j=A.data[t].i;
            B.data[num].e=A.data[t].e;
            num++;
        }
    }
    for(q=0;q<num;q++)
    {
        printf("%d %d %d\n",B.data[q].i,B.data[q].j,B.data[q].e);
    }
    return 0;
}
*/

/*                  -------------ϡ������ת�ã�2������ת��--------------
#include <stdio.h>
#include<stdlib.h>
typedef struct{      //����Ԫ��
    int i,j,e;
}Triple;

typedef struct{       //����
    Triple data[1000];
    int mu,nu,tu;
}TS;
int main()
{
    int p,k,t,q,cp;
    int num[1000];
    int cpot[1000];
    TS A,B;
    scanf("%d %d %d",&A.mu,&A.nu,&A.tu);
    for(p=0;p<A.tu;p++)
    {
        scanf("%d %d %d",&A.data[p].i,&A.data[p].j,&A.data[p].e);
    }

    for(k=0;k<A.nu;k++)//����������
   {
       num[k]=0;
       cpot[k]=0;
   }
   for(p=0;p<A.tu;p++)//����ÿһ�еķ���Ԫ����
   {
       num[A.data[p].j]++;
   }

   cpot[0]=0;
   for(p=1;p<A.nu;p++)//����cpot
   {
       cpot[p]=cpot[p-1]+num[p-1];
   }

   for(p=0;p<A.tu;p++)
   {
       cp=cpot[A.data[p].j];
       B.data[cp].i=A.data[p].j;
       B.data[cp].j=A.data[p].i;
       B.data[cp].e=A.data[p].e;
       cpot[A.data[p].j]++;
   }



    for(q=0;q<A.tu;q++)
    {
        printf("%d %d %d\n",B.data[q].i,B.data[q].j,B.data[q].e);
    }
    return 0;
}
*/

/*                          ------------ϡ�����˷�����bug��------------
#include <stdio.h>
#include<stdlib.h>
typedef struct
{
    int i;
    int j;
    int e;
} Triple;

typedef struct
{
    Triple data[1000];
    int mu;
    int nu;
    int tu;
} TS;

int main()
{
    int p,q,k,arow,brow,ccol,tp,t,number;
    int ctemp[1000]={0};
    int numA[1000]={0};
    int numB[1000]={0};
    int rpotA[1000]={0};
    int rpotB[1000]={0};

    TS A,B,C;
    scanf("%d %d %d",&A.mu,&A.nu,&B.nu);
    B.mu=A.nu;
    C.mu=A.mu;
    C.nu=B.nu;
    C.tu=0;
    scanf("%d",&A.tu);
    for(p=0; p<A.tu; p++) //�������A
    {
        scanf("%d %d %d",&A.data[p].i,&A.data[p].j,&A.data[p].e);
    }
    scanf("%d",&B.tu);
    for(q=0; q<B.tu; q++) //�������B
    {
        scanf("%d %d %d",&B.data[q].i,&B.data[q].j,&B.data[q].e);
    }

     for(k=0;k<A.mu;k++)//����������
   {
       numA[k]=0;
       rpotA[k]=0;
   }
   for(k=0;k<B.mu;k++)//����������
   {
       numB[k]=0;
       rpotB[k]=0;
   }



   for(p=0;p<A.tu;p++)//����ÿһ�еķ���Ԫ����
   {
       numA[A.data[p].i]++;

   }
   printf("%d\n",numA[0]);
   for(p=0;p<B.tu;p++)//����ÿһ�еķ���Ԫ����
   {
       numB[B.data[p].i]++;
   }

   rpotA[0]=0;rpotB[0]=0;
   for(p=1;p<A.mu;p++)//����rpot
   {
       rpotA[p]=rpotA[p-1]+numA[p-1];
   }
    for(p=1;p<B.mu;p++)//����rpot
   {
       rpotB[p]=rpotB[p-1]+numB[p-1];
   }

    for(arow=0;arow<A.mu;arow++)//�Ծ���A�е�ÿһ��
    {
        for(number=0;number<B.nu;number++)
            ctemp[number]=0;
        if(arow<A.mu-1)
            tp=rpotA[arow+1];
        else tp=A.tu+1;
        for(p=rpotA[arow];p<tp;p++)//�Ը����е�ÿ������Ԫ
        {
            brow=A.data[p].j;
            if(brow<B.mu-1)
                t=rpotB[brow+1];
            else t=B.tu+1;
            for(q=brow;q<t;q++)
            {
                ccol=B.data[q].j;
                ctemp[ccol]+=A.data[p].e*B.data[q].e;

            }
        }
        for(k=0;k<B.nu;k++)//�Ѹ��е�ÿһ��Ԫ��ѹ���洢
        {
            if(ctemp[k])
            {
                C.data[C.tu].i=arow;
                C.data[C.tu].j=k;
                C.data[C.tu].e=ctemp[k];
                C.tu++;

                printf("%d %d %d \n",arow,k,ctemp[k]);
            }
        }
    }

    for(k=0;k<C.tu;k++)
    {
        printf("%d %d %d\n",C.data[k].i,C.data[k].j,C.data[k].e);
    }
    return 0;
}
*/


/*                         ------------�����������������������򡢺������----------
             A
       B           C
    D    E

#include<stdio.h>
#include<stdlib.h>
typedef struct BiTNode{
	char data;
	struct BiTNode *lchild, *rchild;
}BiTNode, *BiTree;

void Create(BiTree *T)//��Ϊ�Ǹĵ�ַ�����Զ���*T ������
{
    char ch;
    scanf("%c",&ch);
    if(ch=='#')
        *T=NULL;
    else
    {
        (*T)=(BiTree)malloc(sizeof(BiTNode));
        (*T)->data=ch;
        Create(&(*T)->lchild);
        Create(&(*T)->rchild);
    }
}

void Pre(BiTree T)//��Ϊ��ֻ�������Զ���T ������
{
    if(T==NULL)
        return;
    printf("%c ",T->data);
    Pre(T->lchild);
    Pre(T->rchild);
}

void In(BiTree T)
{
    if(T==NULL)
        return;
    In(T->lchild);
    printf("%c ",T->data);
    In(T->rchild);
}

void Post(BiTree T)
{
    if(T==NULL)
        return;
    Post(T->lchild);
    Post(T->rchild);
    printf("%c ",T->data);
}

int main()//�������ݣ�ABD##E##C##
{
    BiTree T;
    Create(&T);//�����������д���������
    Pre(T);
    printf("\n");
    In(T);
    printf("\n");
    Post(T);
    printf("\n");
    return 0;
}
*/

/*
#include<stdio.h>                 --------------���ݺ��������ԭ������--------------
#include<stdlib.h>

typedef struct BiNode{
    int data;
    struct BiNode *lchild,*rchild;
}BiNode,*BiTree;
int post[40];
int in[40];

BiTree Build(int postl,int postr,int inl,int inr)
{
    if(inl>inr) return NULL;//����
	BiTree root;
    root=(BiTree)malloc(sizeof(BiNode));
	root->data=post[postr];
	int i;
	for(i=inl;i<=inr;i++)
	{
		if(in[i]==post[postr])
		  break;
	}
	int t=i-inl;
	root->lchild=Build(postl,postl+t-1,inl,i-1);
	root->rchild=Build(postl+t,postr-1,i+1,inr);
	return root;

}

int main()
{
    int N,i;
    scanf("%d",&N);
    for(i=1;i<=N;i++)
        scanf("%d",&post[i]);
    for(i=1;i<=N;i++)
        scanf("%d",&in[i]);
    BiTree root=Build(1,N,1,N);
    BiTree tree[100];
    int front=1,rear=1;
    tree[front]=root;
    while(front!=N)
    {
        if(tree[front]->lchild!=NULL)
            tree[++rear]=tree[front]->lchild;
        if(tree[front]->rchild!=NULL)
            tree[++rear]=tree[front]->rchild;
        printf("%d ",tree[front++]->data);
    }
    printf("%d",tree[front++]->data);
    return 0;
}*/

/*
#include<stdio.h>                     ------------���ڽӾ���洢��ͼ��������-------------
#include<stdlib.h>
int num[10][10];
int flag[10];//����Ƿ��з��ʹ�
int ans[10];//��¼����˳��
int k=0,n,m;

void DFS(int x)
{
    int i;
    if(flag[x]==1)
    {
        return;
    }

    flag[x]=1;
    printf("%d ",x);
    ans[k++]=x;
    for(i=0; i<n; i++)
    {
        if(num[x][i]==1&&flag[i]==0)
            DFS(i);

    }
    return;
}

int main()
{
    int t,i,j;
    scanf("%d %d",&n,&m);
    for(i=0; i<n; i++)
        for(j=0; j<n; j++)
            {
                if(i==j)
                    num[i][j]=1;
                else num[i][j]=0;
            }
    for(i=0; i<n; i++)
    {
        flag[i]=0;
    }
    for(t=0; t<m; t++)
    {
        scanf("%d %d",&i,&j);
        num[i][j]=1;
        num[j][i]=1;
    }
    for(i=0; i<n; i++) //��ÿ��δ���ʹ��Ľ���������
    {
        if(flag[i]==0)
        {
            printf("{ ");
            DFS(i);
            printf("}\n");
        }
    }
    for(i=0; i<n; i++)
        printf("%d ",ans[i]);
    return 0;
}*/


#include<stdio.h>                       -----------��·���ͨ��������ķ�㷨��--------------
#include<stdlib.h>
#define INF 999999
typedef struct Node{
    int num;
    int cost;
}Node,*NodeTree;
int N,M;
Node Tree[1010];
int A[1010][1010];
int select[1010];//��ѡ��Ĵ�ׯ
int main()
{
    scanf("%d %d",&N,&M);
    int i,j,k,p=1,mincost,minnum,sum=0,temp;
    for(i=1;i<=N;i++)//��ʼ���ɱ������
        for(j=1;j<=N;j++)
        A[i][j]=INF;
    for(i=1;i<=N;i++)//��ʼ���ɱ������
        {
            Tree[i].cost=INF;
            Tree[i].num=i;
        }
    for(k=1;k<=M;k++)//����ͨ�ɱ������ٽӾ���
    {
        scanf("%d %d %d",&i,&j,&temp);
        A[i][j]=temp;
        A[j][i]=A[i][j];
    }

    Tree[1].cost=0;//��ʾ�����ׯ�ѱ����������ӹ�
    select[p]=1;
    for(j=1;j<=N;j++)//�ȴӵ�һ����ׯ��ʼ����
    {
        if(A[1][j]!=INF)
        {
            Tree[j].cost=A[1][j];
        }
    }
    while(p<N)
    {
        mincost=INF;
        minnum=N+1;
        for(i=1;i<=N;i++)
        {
            if(Tree[i].cost<mincost&&Tree[i].cost!=0)
            {
                mincost=Tree[i].cost;
                minnum=Tree[i].num;
            }
        }
        if(minnum==N+1)//�������ݲ����Ա�֤��ͨ
            break;
        sum+=Tree[minnum].cost;
        Tree[minnum].cost=0;
        select[++p]=minnum;
        for(j=1;j<=N;j++)//�Ե�ǰ��С��ׯ��������,����
      {
        if(A[minnum][j]!=INF)
        {
            if(A[minnum][j]<Tree[j].cost)
            {
                Tree[j].cost=A[minnum][j];
            }
        }
      }
    }
    if(p<N)
        printf("-1\n");
    else
    {
        printf("%d\n",sum);
    }

    return 0;
}


/*
#include<stdio.h>               -----------�ؼ�·��------------
#include<stdlib.h>
#define INF 999999
typedef struct Node{
    int num;
    int indgree;
    int outdegree;
    int in[110];//��1�ŵ�Ԫ��ʼ
    int out[110];
}Node;
int N;//���
int M;//��
Node G[110];
int A[110][110];//�ٽӾ���
int ve[110]={0};//�¼����翪ʼʱ��
int vl[110];//�¼�������ʼʱ��
int key[110];//�ؼ�·��
int main()
{
    Node S[110];
    Node T[110];
    Node tempnode;
    int indegree[110]={0};//����������ȸ���������
    int top1=0;//ָ��ǰ
    int top2=0;
    scanf("%d %d",&N,&M);
    int k,i,j,temp,p=0;
    for(i=1;i<=N;i++)//��ʼ��
    {
        G[i].num=i;
        G[i].indgree=0;
        G[i].outdegree=0;
    }
    for(i=1;i<=N;i++)
        vl[i]=INF;
    for(i=1;i<=N;i++)
        for(j=1;j<=N;j++)
        A[i][j]=INF;
    for(k=1;k<=M;k++)//����
    {
        scanf("%d %d %d",&i,&j,&temp);
        A[i][j]=temp;
        G[i].outdegree++;
        G[i].out[G[i].outdegree]=j;
        G[j].indgree++;
        indegree[j]++;
        G[j].in[G[j].indgree]=i;
    }
    for(i=1;i<=N;i++)//�ѳ�ʼ���Ϊ0�����ջ
    {
        if(G[i].indgree==0)
        {
            S[++top1]=G[i];
            T[++top2]=G[i];
        }
    }
    while(top1!=0)//����ve,���Ұѽ��ѹ��ջT
    {
        tempnode=S[top1--];
        for(i=1;i<=tempnode.outdegree;i++)
        {
            if(ve[tempnode.num]+A[tempnode.num][tempnode.out[i]]>ve[tempnode.out[i]])//����ve
            {
                ve[tempnode.out[i]]=ve[tempnode.num]+A[tempnode.num][tempnode.out[i]];
            }
            G[tempnode.out[i]].indgree--;
            if(G[tempnode.out[i]].indgree==0)
            {
                S[++top1]=G[tempnode.out[i]];
                T[++top2]=G[tempnode.out[i]];
            }
        }
    }
    if(top2!=N)
    {
        printf("0");
        return 0;
    }
    else
        printf("%d\n",ve[N]);//����������ʱ��
    vl[N]=ve[N];

    while(top2!=0)//����vl
    {
        tempnode=T[top2--];
        for(i=1;i<=indegree[tempnode.num];i++)
        {
            if(vl[tempnode.num]-A[tempnode.in[i]][tempnode.num]<vl[tempnode.in[i]])//����vl
            {
                vl[tempnode.in[i]]=vl[tempnode.num]-A[tempnode.in[i]][tempnode.num];
            }
        }

    }
    for(i=1;i<=N;i++)
        if(ve[i]==vl[i])
        key[++p]=i;
    for(i=1;i<=p;i++)
        for(j=p;j>=1;j--)
    {
        if(vl[key[j]]-A[key[i]][key[j]]==vl[key[i]])
            printf("%d->%d\n",key[i],key[j]);
    }
    return 0;
}
*/

/*                                                     -------------���Ͻ�˹�����㷨�����ι滮------------
#include<stdio.h>
#include<stdlib.h>
#define INF 100000
int A[510][510]; //�洢·������
int B[510][510]; //�洢�շ���Ϣ
int len[510];
int cost[510];
int F[510];
int main()
{
    int N,M,S,D,i,j,temp1,temp2,k,index,minnum,minlen;
    scanf("%d %d %d %d",&N,&M,&S,&D);
    for(i=0; i<N; i++) //��ʼ��
    {
        len[i]=INF;
        cost[i]=INF;
        F[i]=0;//��ʼ��Ϊδ���ʹ�
    }
    for(i=0; i<N; i++) //��ʼ��
        for(j=0; j<N; j++)
        {
            A[i][j]=INF;
            B[i][j]=INF;
        }
    for(k=0; k<M; k++) //����
    {
        scanf("%d %d %d %d",&i,&j,&temp1,&temp2);
        A[i][j]=temp1;
        A[j][i]=temp1;
        B[i][j]=temp2;
        B[j][i]=temp2;
    }
    len[S]=0;
    cost[S]=0;
    F[S]=1;
    for(i=0; i<N; i++) //��ʼ����ֱ�Ӹ�ֵ��֮���ֵ��Ҫ��Ӻ���бȽ�
    {
        if(A[S][i]!=INF)
        {
            len[i]=A[S][i];
            cost[i]=B[S][i];
        }
    }
    while(S!=D)
    {
        minlen=INF;
        for(i=0; i<N; i++) //�ҵ���һ����
        {
            if((len[i]<minlen)&&(F[i]==0))
            {
                minnum=i;
                minlen=len[i];
            }
            if(len[i]==minlen&&F[i]==0&&minlen!=INF)
            {
                if(cost[i]<cost[minnum])
                {
                    minnum=i;
                }
            }
        }
        F[minnum]=1;
        S=minnum;
        for(i=0; i<N; i++) //����
        {
            if(A[S][i]!=INF)
            {
                if(len[S]+A[S][i]<len[i])
                {
                    len[i]=len[S]+A[S][i];
                    cost[i]=cost[S]+B[S][i];
                }
                if(len[S]+A[S][i]==len[i])
                {
                    if(cost[S]+B[S][i]<cost[i])
                        cost[i]=cost[S]+B[S][i];
                }
            }
        }
    }
    printf("%d %d",len[D],cost[D]);
    return 0;
}*/

/*                                                         ----------------���м������Ԯ���Ͻ�˹��������Ҫ�����·��������--------------
#include<stdio.h>
#include<stdlib.h>
#define INF 100000
int A[550][550]; //�洢·������
int len[550];
int F[550];
int num[550]= {0}; //����i�����м������·��
int res[550]= {0}; //��i�������ж��پ�Ԯ�ӣ����
int resself[550];
int pre[550];
int select[550];
int main()
{
    int N,M,S,D,i,j,temp1,k,index,minnum,minlen,p=0,resall=0,tempS,tempD;
    scanf("%d %d %d %d",&N,&M,&S,&D);
    tempS=S;tempD=D;
    for(i=0; i<N; i++)
    {
        scanf("%d",&resself[i]);
    }
    for(i=0; i<N; i++) //��ʼ��
    {
        len[i]=INF;
        pre[i]=-1;
        F[i]=0;//��ʼ��Ϊδ���ʹ�
    }
    for(i=0; i<N; i++) //��ʼ��
        for(j=0; j<N; j++)
        {
            A[i][j]=INF;
        }
    for(k=0; k<M; k++) //����
    {
        scanf("%d %d %d",&i,&j,&temp1);
        A[i][j]=temp1;
        A[j][i]=temp1;
    }
    len[S]=0;
    F[S]=1;
    num[S]=1;
    pre[S]=S;
    res[S]=resself[S];

    for(i=0; i<N; i++) //��ʼ����ֱ�Ӹ�ֵ��֮���ֵ��Ҫ��Ӻ���бȽ�
    {
        if(A[S][i]!=INF)
        {
            len[i]=A[S][i];
            num[i]=1;
            res[i]=resself[i]+res[S];
            pre[i]=S;
        }
    }
    while(S!=D)
    {
        minlen=INF;
        for(i=0; i<N; i++) //�ҵ���һ����
        {
            if((len[i]<minlen)&&(F[i]==0))
            {
                minnum=i;
                minlen=len[i];
            }
            else if((len[i]==minlen)&&(F[i]==0))
            {
                if(res[i]>res[minnum])
                    minnum=i;
            }

        }

        F[minnum]=1;
        S=minnum;
        for(i=0; i<N; i++) //����
        {
            if(A[S][i]!=INF)
            {
                if(len[S]+A[S][i]<len[i])
                {
                    len[i]=len[S]+A[S][i];
                    res[i]=res[S]+resself[i];
                    num[i]=num[S];
                    pre[i]=S;
                }
                else if(len[S]+A[S][i]==len[i])
                {
                    num[i]+=num[S];
                    if(res[S]+resself[i]>res[i])
                    {
                        res[i]=res[S]+resself[i];
                        pre[i]=S;
                    }

                }
            }
        }
    }
    select[p++]=D;
    while(D!=tempS)
    {
        D=pre[D];
        select[p++]=D;

    }
    printf("%d %d\n",num[tempD],res[tempD]);
    for(i=p-1; i>0; i--)
        printf("%d ",select[i]);
    printf("%d",select[0]);
    return 0;
}
*/

/*                                              ------------------�շ�������-----------------
#include<stdio.h>
#include<stdlib.h>
#define INF 99999
typedef struct Node
{
    int weight;
    int parent;
    int lchild;
    int rchild;
} Node;

typedef struct Code
{
    char HCode[300];//��0�ſ�ʼ��
    int len;
} Code;
Node HuffNode[100];
Code HuffCode[100];
int n;

int main()
{
    int i,j,m,k,min1=INF,min2=INF,minnum1=0,minnum2=0,temp,pre;
    scanf("%d",&n);
    m=2*n-1;
    for(i=1; i<=m; i++)
    {
        HuffNode[i].parent=0;
        HuffNode[i].lchild=0;
        HuffNode[i].rchild=0;
        HuffCode[i].len=0;
    }
    for(i=1; i<=n; i++) //����Ȩֵ
    {
        scanf("%d",&HuffNode[i].weight);
    }

    for(i=n+1; i<=m; i++) //�ӵ�n+1����ʼ��ֵ
    {
        minnum1=0;
        minnum2=0;
        min1=INF,min2=INF;
        for(k=1; k<i; k++) //ɨ��ǰ��
        {
            if(HuffNode[k].weight<min1&&HuffNode[k].parent==0)//����С
            {
                min2=min1;
                min1=HuffNode[k].weight;
                minnum2=minnum1;
                minnum1=k;
            }
            else if(HuffNode[k].weight<min2&&HuffNode[k].parent==0)//�Ҵ�С
            {
                min2=HuffNode[k].weight;
                minnum2=k;
            }
        }
        HuffNode[minnum1].parent=i;
        HuffNode[minnum2].parent=i;
        if(minnum1<minnum2)
        {
            HuffNode[i].lchild=minnum1;
            HuffNode[i].rchild=minnum2;
        }
        else
        {
            HuffNode[i].lchild=minnum2;
            HuffNode[i].rchild=minnum1;
        }
        HuffNode[i].weight=HuffNode[minnum1].weight+HuffNode[minnum2].weight;
    }
    for(i=1; i<=n; i++) //�����
    {
        temp=i;
        pre=HuffNode[i].parent;
        while(pre!=0)
        {
            if(HuffNode[pre].lchild==temp)
            {
                HuffCode[i].HCode[HuffCode[i].len++]='0';
            }
            else if(HuffNode[pre].rchild==temp)
            {
                HuffCode[i].HCode[HuffCode[i].len++]='1';
            }
            temp=pre;
            pre=HuffNode[temp].parent;
        }
    }
    for(i=1; i<=n; i++)
    {
        for(j=HuffCode[i].len-1; j>=0; j--)
        {
            printf("%c ",HuffCode[i].HCode[j]);
        }
        printf("\n");
    }
    return 0;
}

*/




