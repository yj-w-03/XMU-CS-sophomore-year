//app.js
App({
  onLaunch: function () {
    var goods = wx.getStorageSync('goods');
    if(!goods){
        goods = this.loadGoods();
    }
    wx.setStorageSync('goods', goods);
  },
   loadGoods:function(){
    
    var goods = new Array();
    var good = new Object();

    good.id="1000";//商品唯一标识
    good.pic = '/images/pic/3090(2).jpg'; //商品图片
    good.name='MSI/微星RTX 3090万图师/魔龙24G全新英伟达独立显卡';//商品名称
    good.nowPrice='13999';//商品现价
    good.oldPrice = '16999';//商品原价
    good.soldCount = '31';//商品售出数量
    good.coupon = ['满1050减60','满20000减1600'];//商品优惠券
    good.promotion = ['限购', '限制','满减'];//商品促销
    good.color = ['RTX 3080','RTX 3090','RTX 3060Ti'];//商品颜色
    good.count = 1;//商品数量
    good.address='福建省 厦门市 翔安区';//商家地址
    good.promise = ['99元免费基础运费', '京东发货&售后', '七天退货', '211限时达', '货到付款'];//商家承诺
    good.desc = '10:00之前下单，预计第二天送达';//商品说明
    good.photos = ['/images/haibao/3090/3090.jpg', '/images/haibao/3090/3090(2).jpg', '/images/haibao/3090/3090(3).jpg', '/images/haibao/3090/3090(4).jpg'];//商品组图
    good.isjd = "1";//是否是自营，1代表自营，0代表不是自营
    goods[0] = good;

    var good1 = new Object();
    good1.id = "1001";//商品唯一标识
    good1.pic = '/images/pic/ipad.png'; //商品图片
    good1.name = '2020新款Apple/苹果 10.2英寸iPad平板电脑ipad8';//商品名称
    good1.nowPrice = '2999.00';//商品现价
    good1.oldPrice = '3000.00';//商品原价
    good1.soldCount = '51';//商品售出数量
    good1.coupon = ['满1999减40', '满3000减100'];//商品优惠券
    good1.promotion = ['限购', '限制', '满减'];//商品促销
    good1.color = ['白色', '黑色'];//商品颜色
    good1.size = ['128G','256G'];//商家尺寸
    good1.count = 1;//商品数量
    good1.address = '福建省 厦门市 翔安区';//商家地址
    good1.promise = ['商家发货&售后', '七天退货', '货到付款', '运费险'];//商家承诺
    good1.desc = '免运费';//商品说明
    good1.photos = ['/images/haibao/ipad/ipad.png', '/images/haibao/ipad/ipad2.jpg', '/images/haibao/ipad/ipad3.jpg'];//商品组图
    good1.isjd = "0";//是否是自营，1代表自营，0代表不是自营
    goods[1] = good1;

    var good2 = new Object();
    good2.id = "1002";//商品唯一标识
    good2.pic = '/images/pic/bag.jpg'; //商品图片
    good2.name = 'CAMEL骆驼户外男女旅行 收纳防水罩背负系统登山包';//商品名称
    good2.nowPrice = '178.00';//商品现价
    good2.oldPrice = '349.00';//商品原价
    good2.soldCount = '15';//商品售出数量
    good2.coupon = ['满299减20', '满499减50'];//商品优惠券
    good2.promotion = ['限购', '限制'];//商品促销
    good2.color = ['黑色', '红色', '彩蓝', '墨绿'];//商品颜色
    good2.count = 1;//商品数量
    good2.address = '福建省 厦门市 翔安区';//商家地址
    good2.promise = ['商家发货&售后', '七天退货', '货到付款'];//商家承诺
    good2.desc = '店铺单笔订单不满59元，收运费10元';//商品说明
    good2.photos = ['/images/haibao/bag/1.jpg', '/images/haibao/bag/2.jpg', '/images/haibao/bag/3.jpg', '/images/haibao/bag/4.jpg', '/images/haibao/bag/5.jpg'];//商品组图
    good2.isjd = "0";//是否是自营，1代表自营，0代表不是自营
    goods[2] = good2;

    var good3 = new Object();
    good3.id = "1003";//商品唯一标识
    good3.pic = '/images/pic/purifier.jpg'; //商品图片
    good3.name = 'airx A7F净化器 甲醛CADR 400立方米每小时 持续吸附甲醛山包';//商品名称
    good3.nowPrice = '2849.00';//商品现价
    good3.oldPrice = '2899.00';//商品原价
    good3.soldCount = '23';//商品售出数量
    good3.promotion = ['加价购', '限购', '限制'];//商品促销
    good3.count = 1;//商品数量
    good3.address = '福建省 厦门市 翔安区';//商家地址
    good3.promise = ['99元免基础运费(20kg内)', '京东发货&售后', '七天退货', '211限时达', '货到付款'];//商家承诺
    good3.desc = '10：00前下单，预计第二天送达';//商品说明
    good3.photos = ['/images/haibao/purifier/1.jpg', '/images/haibao/purifier/2.jpg', '/images/haibao/purifier/3.jpg', '/images/haibao/purifier/4.jpg', '/images/haibao/purifier/5.jpg'];//商品组图
    good3.isjd = "1";//是否是自营，1代表自营，0代表不是自营
    goods[3] = good3;

    var good4 = new Object();
    good4.id = "1004";//商品唯一标识
    good4.pic = '/images/pic/haier.jpg'; //商品图片
    good4.name = '海尔（Haier） 1.5匹 冷暖 变频';//商品名称
    good4.nowPrice = '3698.00';//商品现价
    good4.oldPrice = '4299.00';//商品原价
    good4.soldCount = '32';//商品售出数量
    good4.promotion = ['加价购', '限购', '限制', '优惠套装'];//商品促销
    good4.count = 1;//商品数量
    good4.color = ['大1匹', '1.5匹'];//商品颜色
    good4.address ='福建省 厦门市 翔安区';//商家地址
    good4.promise = ['99元免基础运费(20kg内)', '京东发货&售后', '七天退货', '货到付款', '家电净洗'];//商家承诺
    good4.desc = '18：00前下单，预计第二天送达';//商品说明
    good4.photos = ['/images/haibao/haier/1.jpg', '/images/haibao/haier/2.jpg', '/images/haibao/haier/3.jpg', '/images/haibao/haier/4.jpg', '/images/haibao/haier/5.jpg'];//商品组图
    good4.isjd = "1";//是否是自营，1代表自营，0代表不是自营
    goods[4] = good4;

    return goods;

  },
  getUserInfo:function(cb){
    var that = this
    if(this.globalData.userInfo){
      typeof cb == "function" && cb(this.globalData.userInfo)
    }else{
      //调用登录接口
      wx.login({
        success: function () {
          wx.getUserInfo({
            success: function (res) {
              that.globalData.userInfo = res.userInfo
              typeof cb == "function" && cb(that.globalData.userInfo)
            }
          })
        }
      })
    }
  },
  globalData:{
    userInfo:null
  }
})