Page({
  data: {
    currentTab: 0,
    coupons: []
  },
  onLoad: function (options) {
    var coupons = this.loadCoupons(0);
    this.setData({coupons:coupons});
  },
  switchNav: function (e) {
    var page = this;
    var index = e.target.dataset.current;
    if (this.data.currentTab == index) {
      return false;
    } else {
      page.setData({ currentTab: index });
    }
    var coupons = this.loadCoupons(index); 
    page.setData({coupons:coupons});
  },
  loadCoupons: function (flag) {
    var coupons = new Array();
    var coupon = new Object();
    coupon.id = "1";
    coupon.price = "1";
    
    coupon.goods = "[DAZZLE官方旗舰店]";
    coupon.way = "有满减优惠";
    coupon.date = "点击抢购";
    coupon.type="0";
    coupons.push(coupon);

    var coupon2 = new Object();
    coupon2.id = "2";
    coupon2.price = "2";
   
    coupon2.goods = "[nerdy官方旗舰店]";
    coupon2.way = "有满减优惠";
    coupon2.date = "点击抢购";
    coupon2.type="0";
    coupons.push(coupon2);

    var coupon3 = new Object();
    coupon3.id = "3";
    coupon3.price = "3";
    
    coupon3.goods = "[R13官方旗舰店]";
    coupon3.way = "有满减优惠";
    coupon3.date = "点击抢购";
    coupon3.type="0";
    coupons.push(coupon3);

    var coupon4 = new Object();
    coupon4.id = "4";
    coupon4.price = "4";
   
    coupon4.goods = "[MaxMara官方旗舰店]";
    coupon4.way = "有满减优惠";
    coupon4.date = "点击抢购";
    coupon4.type="0";
    coupons.push(coupon4);

    var coupon5 = new Object();
    coupon5.id = "5";
    coupon5.price = "1";
   
    coupon5.goods = "[SK-II官方旗舰店]";
    coupon5.way = "有满减优惠";
    coupon5.date = "点击抢购";
    coupon5.type="1";
    coupons.push(coupon5);

    var coupon6 = new Object();
    coupon6.id = "6";
    coupon6.price = "2";
   
    coupon6.goods = "[Dior官方旗舰店]";
    coupon6.way = "有满减优惠";
    coupon6.date = "点击抢购";
    coupon6.type="1";
    coupons.push(coupon6);

    var coupon7 = new Object();
    coupon7.id = "7";
    coupon7.price = "3";
    
    coupon7.goods = "[丝芙兰官方旗舰店]";
    coupon7.way = "有满减优惠";
    coupon7.date = "点击抢购";
    coupon7.type="1";
    coupons.push(coupon7);

    var coupon8 = new Object();
    coupon8.id = "8";
    coupon8.price = "1";
    
    coupon8.goods = "[三只松鼠官方旗舰店]";
    coupon8.way = "有满减优惠";
    coupon8.date = "点击抢购";
    coupon8.type="2";
    coupons.push(coupon8);
    var result = new Array();
    for(var i=0;i<coupons.length;i++){
       if(flag==coupons[i].type){
          result.push(coupons[i]);
       }
    }
    return result;
  }
})