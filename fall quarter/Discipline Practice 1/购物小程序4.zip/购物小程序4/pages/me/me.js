Page({
  data:{
    userInfo:{}
  },
  onLoad:function(){
    var page = this;
    wx.getSetting({
      success(res) {
        if (!res['scope.userInfo']) {
          wx.authorize({//获取用户授权
            scope: 'scope.userInfo',
            success() {
                wx.getUserInfo({
                  success: function (res) {
                    var userInfo = res.userInfo
                    page.setData({userInfo:userInfo});
                  }
              })
            }
          })
        }
      }
    })
    wx.setNavigationBarTitle({//动态修改页面标题文字
      title: '我的'
    })
    wx.setNavigationBarColor({
      frontColor: '#000000',//导航文字颜色
      backgroundColor: '#1fccd5',//导航背景色
      animation: {//动画效果
        duration: 400,
        timingFunc: 'easeIn'
      }
    })
  },
  seeCoupon: function () {
    wx.navigateTo({
      url: '../coupon/coupon'
    })
  },
  seetransportation: function () {
    wx.navigateTo({
      url: '../transportation/transportation'
    })
  }
})