Page({
  data:{
    orders:[],//加入到购物车里的商品集合
    selectedAll:false,//全选按钮标志位，true代表全选选中，false代表全选未选中
    totalPrice:0 //总金额
  },
  onLoad:function(options){
    this.loadOrders();
    wx.setNavigationBarTitle({//动态修改页面标题文字
      title: '待收货'
    })
    wx.setNavigationBarColor({
      frontColor: '#000000',//导航文字颜色
      backgroundColor: '#1fccd5',//导航背景色
      animation: {//动画效果
        duration: 400,
        timingFunc: 'easeIn'
      }
    })
  },  
  loadOrders:function(){ //加载购物车里的商品
    var orders = wx.getStorageSync('orders');//从本地缓存数据orders里获取数据
     var newOrders = [];
     var totalPrice=0;
     var selectedAll = true;
      for(var i=0;i < orders.length;i++){
         var order = orders[i];
         if (order.selected){//购物车里的每件商品都有一个selected属性，selected等于true时代表这件商品被选中，要计算金额
           totalPrice += order.nowPrice * order.quantity;//计算选中商品的金额，
         }else{
           selectedAll = false;//购物车里的商品，如果有一件是未选中的，selectedAll全选标志位就等于false
         }
         newOrders.push(order);
      }
      wx.setStorageSync("orders", newOrders);//重新加入缓存
      this.setData({ totalPrice: totalPrice, orders: newOrders, selectedAll: selectedAll});//数据绑定到页面里
  },
  checkboxChange:function(e){//每件商品前的复选框操作函数
    var ids = e.detail.value;//会把选中的复选框的id值，以数组集合的形式传递过来
    var orders = wx.getStorageSync('orders');
    var totalPrice=0;
    var newOrders = [];
    for(var i=0;i < orders.length;i++){
      var order = orders[i];
      var flag = true;
       for(var j=0;j < ids.length;j++){
           if(order.id == ids[j]){//传递过来的ids数组集合值，都是选中的商品，需要计算总的金额
             totalPrice += order.nowPrice * order.quantity;
             order.selected = true;//代表改件商品是选中状态
             flag = false;//代表改件商品是选中状态
           }
       }
       if (flag) {//代表改件商品是未选中状态
         order.selected = false;
       }
       newOrders.push(order);
    }
    wx.setStorageSync("orders", newOrders);//重新加入缓存数据
    this.loadOrders();//重新加载页面
  },
  checkAll:function(e){//全选复选框操作函数
    var orders = wx.getStorageSync("orders");
    console.log(e);
    var newOrders = [];
    var selectedAll = this.data.selectedAll;
    for(var i=0;i<orders.length;i++){
        var order = orders[i];
        if (selectedAll){//如果当前状态值是全选中，那么再单击的时候，全选复选框应该为未选中状态
          order.selected = false;
        }else{
          order.selected = true;
        }
        newOrders.push(order);
    }
    wx.setStorageSync("orders", newOrders)//重新加入缓存数据
    this.loadOrders();//重新加载页面
  },
  addOrders: function (e) {//添加商品数量函数
    var id = e.currentTarget.id;
    var orders = wx.getStorageSync('orders');
    var addOrders = new Array();
    for (var i = 0; i < orders.length; i++) {
      var order = orders[i];
      if (order.id == id) {
        var quantity = order.quantity;
        order.quantity = quantity + 1;//找到该件商品数量加1
      }
      addOrders[i] = order;
    }
    wx.setStorageSync('orders', addOrders);//重新加入缓存数据
    this.loadOrders();//重新加载页面
  },
  minusOrders: function (e) {//减少商品数量函数
    console.log(e);
    var id = e.currentTarget.id;
    var orders = wx.getStorageSync('orders');
    var addOrders = new Array();
    var add = true;
    for (var i = 0; i < orders.length; i++) {
      var order = orders[i];
      if (order.id == id) {
        var count = order.quantity;
        if(count >= 2){
          order.quantity = count - 1;//找到该件商品数量减1
        }
      }
      addOrders[i] = order;
    }
    wx.setStorageSync('orders', addOrders);//重新加入缓存数据
    this.loadOrders();//重新加载页面
  }
})