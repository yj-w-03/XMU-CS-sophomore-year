Page({
  data:{
    goods:[],
    imgs:['/../images/pic/car.PNG','/../images/pic/aj1.PNG','/../images/pic/iphone.PNG','/../images/pic/hat.png']
  },
  search:function(){
    wx.navigateTo({
      url: '../search/search'
    })
  },
  onLoad:function(){
    this.loadGoods();
  },
  loadGoods:function(){
    var page = this;
    var goods = wx.getStorageSync("goods");
    page.setData({goods:goods});
  },
  detail:function(e){
    console.log(e);
    var id = e.target.id;
    console.log(id);
    wx.navigateTo({
      url: '../detail/detail?id='+id,
    })
  },
  scanCodeEvent: function(){
    var that = this;
    wx.scanCode({
      onlyFromCamera: true,// 只允许从相机扫码
      success(res){
        console.log("扫码成功："+JSON.stringify(res))
 
        // 扫码成功后  在此处理接下来的逻辑
        that.setData({
          scanCode: res.result
        })
      }
    })
  },
  onShareAppMessage: function (res) {
    return {
      title: '厦大购物首页',
      path: '/page/index/index',
      success: function (res) {
          // 转发成功
      },
      fail: function (res) {
        // 转发失败
      }
    }
  },
  getCoupon: function () {
    wx.navigateTo({
      url: '../couponsss/couponsss'
    })
  },
  getCoupon: function () {
    wx.navigateTo({
      url: '../Getcoupon/Getcoupon'
    })
  },
  seetransportation: function () {
    wx.navigateTo({
      url: '../transportation/transportation'
    })
  },
  seeclassify: function () {
    wx.navigateTo({
      url: '../classify/classify'
    })
  }
})