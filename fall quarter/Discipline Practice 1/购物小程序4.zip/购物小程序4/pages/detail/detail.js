Page({
  data: {
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000,
    imgUrls: [],
    good:{},
    quantity:0
  },
  onLoad:function(e){
    var id = e.id;
    this.initData(id);
    var orders = wx.getStorageSync("orders");
    this.setData({ quantity: orders.length});
  },
  initData:function(id){//渲染商品信息
    var goods = wx.getStorageSync("goods");
    var good = {};
    for (var i = 0; i < goods.length; i++) {
      var g = goods[i];
      if (g.id == id) {
        var isjd = g.isjd;
        if(isjd=="1"){
          g.name = "【自营】" + g.name;
        }
        good = g;
        break;
      }
    }
    console.log(good);
    var page = this;
    page.setData({ imgUrls: good.photos,good:good});
  },
  addGood:function(e){//添加商品到购物车
    console.log(e);
    var id = e.target.id;
    var orders = wx.getStorageSync("orders");
    var flag=true;
    var newOrders=[];
    if (orders){//先判断购物车里是否有该商品，如果有，就在数量上加1
       for(var i=0;i<orders.length;i++){
          var order = orders[i];
          if(id==order.id){
             order.quantity = order.quantity +1;
             flag=false;
          }
          newOrders.push(order);
       }
    }
    if(flag){//如果购物车里没有商品,就添加到购物车里
      var goods = wx.getStorageSync("goods");
      for(var i=0;i<goods.length;i++){
          var good = goods[i];
          if(id==good.id){
            good.quantity=1;
            newOrders.push(good);
            break;
          }
      }
    }
    wx.setStorageSync("orders", newOrders);//将商品保存到本地数据
    wx.showToast({//提示保存成功
      title: '成功',
      icon: 'success',
      duration: 2000
    });
    var page = this;
    page.setData({ quantity: newOrders.length});//购物车数量显示
  },
  buy:function(e){//直接购买
    var id = e.target.id;
    wx.navigateTo({
      url: '../buy/buy?id='+id,
    })
  },
  cart:function()
  {
    wx.switchTab({
      url:'../shoppingcart/shoppingcart',
    })
  }
})

