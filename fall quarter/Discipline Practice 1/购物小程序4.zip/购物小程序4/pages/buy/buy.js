Page({
  data:{
    order:1,
    good:{}
  },
  onLoad: function (e) {
    console.log(e);
    var id = e.id;
    console.log(id);
    var goods = wx.getStorageSync("goods");
    for (var i = 0; i < goods.length; i++) {
      var good = goods[i];
      if (id == good.id) {
        this.setData({ good: good });
        break;
      }
    }
  },
  addOrders: function () {//添加商品数量函数
    var noworder=this.data.order+1;
    this.setData({order:noworder})
  },
  minusOrders: function () {//减少商品数量函数
    var noworder=this.data.order-1;
    this.setData({order:noworder>0?noworder:1})
  }
})