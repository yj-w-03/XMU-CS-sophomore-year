Page({
  data: {
    result: [],
    name:''
  },
  searchGoods: function (e) {//搜索商品
    var name = e.detail.value;
    var goods = this.loadGoods();
    var result = new Array();
    if (name != '') {
      for (var i = 0; i < goods.length; i++) {
        var good = goods[i];
        if (good.indexOf(name) > -1) {
          result.push(good);
        }
      }
    }
    console.log(result);
    this.setData({ result: result });
  },
  loadGoods: function () {
    var goods = ['八宝粥自营', '八宝粥原料', '八宝粥米', '八宝粥箱', '八宝粥杂粮', '八宝粥银鹭', '八宝粥料', '空调扇', '空调挂机', '空调被', '空调柜机', '空调自营', '空调扇 制冷', '空调挡风被',];
    return goods;
  },
  resetSearch:function(){//返回上一级页面
    wx.navigateBack({
      delta: 1
    })
  }

})